public interface Payable {
    public abstract int getAmountToPay();
    public abstract String getDescription();
}
